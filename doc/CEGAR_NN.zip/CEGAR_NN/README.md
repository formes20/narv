# CEGAR_NN
Counter Example Guided Abstraction and Refinement Mechanism for Neural Networks
