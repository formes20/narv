#!/usr/bin/env python3

# currently not implemented here, but in refinement_utils along with cegar
raise NotImplementedError("cetar is implemented in refinement_utils")
