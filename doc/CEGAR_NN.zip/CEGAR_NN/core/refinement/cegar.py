#!/usr/bin/env python3

# currently not implemented here, but in refinement_utils along with cetar
raise NotImplementedError("cegar is implemented in refinement_utils")
